#include "main.h"

void swap(int *x, int *y);
/* Function to partition the array */
int partition(int *arr, int first, int last)
{
    //declaration variables
    int pivot,start,end,index;
    
    pivot=first;        //it is pointing to 0th index
    start=first;          //0st index
    end=last;             //last index
    
    
    while(start < end)       //cond is true until the start index in less than end index      
    {
        while(arr[start] <= arr[pivot])  //if the 0th index is greater than the start index
        {
            start++;    //inc p-> start from index            
        }
        while(arr[end] > arr[pivot])  //if the 0th index is greater than the end index
        {
            end--;    //dec q-> end  from index
        }
        if(start < end)    //if the start index is less than end index 
        {
            swap(&(arr[start]),&(arr[end]));    //swap the star and end index
        }
    }
    swap(&(arr[pivot]),&(arr[end]));     //at last swap the 0th index to the current end index
    return end;
}
    
    //swapping func
    void swap(int *element1, int *element2)
    {
        int temp;
        temp = *element1;
        *element1 = *element2;
        *element2 = temp;
    }
    

