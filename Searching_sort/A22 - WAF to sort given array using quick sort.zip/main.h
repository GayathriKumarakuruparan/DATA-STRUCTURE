/*
Name                    :   GAYATHRI.K
Date                    :   14.12.2023
Description             :   Sorting array using Quick sort
Sample execution        :   emertxe@ubuntu:~/ECEP/DS/Assign22$ make
                            cc    -c -o partition.o partition.c
                            cc    -c -o main.o main.c
                            cc    -c -o quick_sort.o quick_sort.c
                            gcc -o out.exe partition.o main.o quick_sort.o  
                            emertxe@ubuntu:~/ECEP/DS/Assign22$ ./out.exe
                            Enter the size of an array
                            5
                            Enter the array elements
                            9 7 5 8 1
                            Sorted array is : 1 5 7 8 9 
                            emertxe@ubuntu:~/ECEP/DS/Assign22$ 

*/
#ifndef MAIN_H
#define MAIN_L

#include <stdio.h>

int quick_sort(int *, int, int );
int partition(int *, int , int );

#endif
