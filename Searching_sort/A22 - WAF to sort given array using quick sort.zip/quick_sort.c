#include "main.h"

/* Function to sort the array in quick sort method */
int quick_sort( int *arr, int first, int last )
{
     int index;
     if(first < last)
     {	//calling quicksort function with modified first and last when first is lesser than last and temp from partitioned array
    	index= partition(arr, first, last);
    	quick_sort(arr, first, index - 1);            //left separation
    	quick_sort(arr, index + 1, last);             //right separation
     }
}
